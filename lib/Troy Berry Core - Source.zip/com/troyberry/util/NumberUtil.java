package com.troyberry.util;

import com.troyberry.math.*;

public class NumberUtil {
	
	public static double truncate(double number, int decimalPlaces) {
		decimalPlaces = Maths.clamp(0, 8, decimalPlaces);
		long numberToMultiply = Maths.pow(10, decimalPlaces);
		number *= numberToMultiply;
		number = (int)number;
		number /= numberToMultiply;
		return number;
	}
	
	public static double roundOff(double number, int decimalPlaces) {
		decimalPlaces = Maths.clamp(0, 8, decimalPlaces);
		long numberToMultiply = Maths.pow(10, decimalPlaces);
		number *= numberToMultiply;
		number = Maths.round(number);
		number /= numberToMultiply;
		return number;
	}
	
	public static float truncate(float number, int decimalPlaces) {
		long numberToMultiply = Maths.pow(10, decimalPlaces);
		number *= numberToMultiply;
		number = (int)number;
		number /= numberToMultiply;
		return number;
	}
	
	public static float roundOff(float number, int decimalPlaces) {
		decimalPlaces = Maths.clamp(0, 8, decimalPlaces);
		long numberToMultiply = Maths.pow(10, decimalPlaces);
		number *= numberToMultiply;
		number = Maths.round(number);
		number /= numberToMultiply;
		return number;
	}

}
