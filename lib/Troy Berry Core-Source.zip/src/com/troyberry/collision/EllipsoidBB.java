package com.troyberry.collision;

import com.troyberry.math.*;

public class EllipsoidBB {

	public final float radiusX, radiusY, radiusZ;
	public final AxisAlignedBB box;

	public EllipsoidBB(float radiusX, float radiusY, float radiusZ) {
		this.radiusX = radiusX;
		this.radiusY = radiusY;
		this.radiusZ = radiusZ;
		this.box = new AxisAlignedBB(-radiusX, -radiusY, -radiusZ, radiusX, radiusY, radiusZ);
	}

	/**
	 * Returns a bounding box expanded by the specified vector (if negative
	 * numbers are given it will shrink)
	 */
	public EllipsoidBB expand(float rx, float ry, float rz) {
		float newrx = radiusX + rx;
		float newry = radiusY + ry;
		float newrz = radiusZ + rz;
		return new EllipsoidBB(newrx, newry, newrz);
	}

	public boolean intersects(Vector3f thisPosition, EllipsoidBB other, Vector3f otherPosition) {
		if (this.box.intersectsWith(thisPosition, other.box, otherPosition)) {
			// TODO: This is to hard do later
		}
		return false;
	}

	/**
	 * Returns if the supplied Vector3f is completely inside the bounding box
	 */
	public boolean isVecInside(Vector3f thisPosition, Vector3f vec) {
		return Math.pow((vec.x - thisPosition.x) / radiusX, 2.0) + Math.pow((vec.y - thisPosition.y) / radiusY, 2.0)
				+ Math.pow((vec.z - thisPosition.z) / radiusZ, 2.0) < 1.0f;
	}

}
