package com.troyberry.logging;

public class Time {

	public static long delta = 1;
	
	public static long getDelta() {
		return delta;
	}
	
	public static void setDelta(long delta) {
		Time.delta = delta;	
	}
}
