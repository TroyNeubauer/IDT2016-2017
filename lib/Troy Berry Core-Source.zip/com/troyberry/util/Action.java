package com.troyberry.util;

public abstract class Action {
	public abstract void onAction(Object object);
}
