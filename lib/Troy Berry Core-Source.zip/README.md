# Troy-Berry-Core
Is a libary that I use in all of my games. It has many utility features such as logging, noise generation, 2, 3 and 4 dimensional vector classes with math methoids, 4x4 matrices and so on.
