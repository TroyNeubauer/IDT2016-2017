package com.troyberry.util;

public class DefalutVersion extends IVersion {

	public DefalutVersion() {
		super("Troy Berry Game", 0, 1, 0);
	}

}
