package com.troyberry.util.data;

import java.util.*;

import com.troyberry.math.*;

public class MyArray <E> {
	
	private volatile Object[] data;
	public static final int DEFAULT_SIZE = 32;
	public static final int RESIZE_MULTIPLIER = 2;
	private volatile int pointer;
	
	public MyArray(int size) {
		if(size >= 0) data = new Object[size];
		else throw new IllegalArgumentException("Negative sizes are not allowed!");
	}
	
	public MyArray() {
		this(DEFAULT_SIZE);
	}
	
	public synchronized E get(int index) {
		if(index - data.length < 0) {
				return (E) data[index];
		} else {
			resize();
		}
		
		return null;
	}
	
	public synchronized E remove(int index) {
		checkRange(index);
		E oldValue = (E) data[index];
		int numMoved = pointer - index - 1;
        System.arraycopy(data, index+1, data, index, numMoved);
        data[data.length - 1] = null;
        return oldValue;
	}
	
	public synchronized void set(int index, E value) {
		if(index - data.length >= 0) {
			resize();
		}
		data[index] = value;
	}
	
	public synchronized void add(E value) {
		set(pointer++, value);
	}

	private synchronized void resize() {
		data = Arrays.copyOf(data, data.length * RESIZE_MULTIPLIER);
	}
	
	public synchronized int size() {
		return pointer;
	}
	
	public synchronized int capacity() {
		return data.length;
	}
	
	public synchronized void checkRange(int index) { 
		if (index >= data.length || index < 0) throw new IndexOutOfBoundsException("Index out of bounds for array! " + index);
	}
}
