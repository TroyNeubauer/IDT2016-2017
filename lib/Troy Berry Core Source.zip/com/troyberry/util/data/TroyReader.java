package com.troyberry.util.data;

import java.awt.image.*;
import java.io.*;
import java.nio.*;

import com.troyberry.util.*;

/**
 * A class used for reading binary files, streams and arrays
 * @author Troy Neubauer
 *
 */
public class TroyReader {
	
	private ByteBuffer buffer;
	
	/**
	 * Sets the bytes to use in this reader to a new array of bytes
	 * @param data The new byte array
	 */
	public void set(byte[] data) {
		buffer = ByteBuffer.wrap(data);
	}

	/**
	 * Creates a new reader with the following data
	 * @param data The data to start with
	 */
	public TroyReader(byte[] data) {
		set(data);
	}
	
	/**
	 * Reads the available bytes from a InputStream to this reader
	 * @param stream The stream to read from
	 * @throws IOException If an IO Error occurs while reading the stream
	 */
	public TroyReader(InputStream stream) throws IOException {
		byte[] data = new byte[stream.available()];
		stream.read(data);
		stream.close();
		set(data);
	}
	
	/**
	 * Creates a new reader with the data from the specified file assuming it exists
	 * @param file The file to read from
	 * @throws IOException If an IO Error occurs while reading the file
	 */
	public TroyReader(File file) throws IOException {
		
		if(file == null) throw new NullPointerException("File can't be null!");
		byte[] data = new byte[(int) file.length()];
		FileInputStream stream = new FileInputStream(file);
		stream.read(data);
		set(data);
	}
	
	/**
	 * Creates a new Reader from the bytes in a TroyWriter
	 * @param writer The writer to copy from
	 */
	public TroyReader(TroyWriter writer) {
		set(writer.getBytes());
	}
	
	/**
	 * Copies the desired amount of bytes from the current pointer to the current pointer + length exclusive
	 * @param length The amount of bytes to read
	 * @return The bytes from the current pointer to the current pointer + length exclusive
	 * @throws BufferUnderflowException If the reader reaches the end of the stream of bytes, IE <code>pointer + length > reader's length</code>
	 */
	public byte[] readBytes(int length){
		byte[] result = new byte[length];
		for(int i = 0; i < length; i++) {
			result[i] = readByte();
		}
		return result;
	}
	
	/**
	 * Returns a copy of the data in this reader
	 * @return The data in this reader
	 */
	public byte[] getBytes() {
		byte[] result = new byte[buffer.capacity()];
		buffer.get(result);
		return result;
	}
	
	/**
	 * Reads the next byte then increments the pointer.
	 * @return The read byte
	 */
	public byte readByte(){
		return buffer.get();
	}
	
	/**
	 * Reads the next two bytes at this reader's current position, composing them into a short value, 
	 * and then increments the pointer by two.
	 * @return The read short
	 * @throws BufferUnderflowException If there are fewer than two bytes remaining in this reader
	 */
	public short readShort(){
		return buffer.getShort();
	}
	
	/**
	 * Reads the next four bytes at this reader's current position, composing them into a int value, 
	 * and then increments the pointer by four.
	 * @return The read int
	 * @throws BufferUnderflowException If there are fewer than four bytes remaining in this reader
	 */
	public int readInt(){
		return buffer.getInt();
	}
	
	/**
	 * Reads the next eight bytes at this reader's current position, composing them into a long value, 
	 * and then increments the pointer by eight.
	 * @return The read long
	 * @throws BufferUnderflowException If there are fewer than eight bytes remaining in this reader
	 */
	public long readLong() {
		return buffer.getLong();
	}
	
	/**
	 * Reads the next four bytes at this reader's current position, composing them into a float value, 
	 * and then increments the pointer by four.
	 * @return The read short
	 * @throws BufferUnderflowException If there are fewer than four bytes remaining in this reader
	 */
	public float readFloat() {
		return buffer.getFloat();
	}
	
	/**
	 * Reads the next eight bytes at this reader's current position, composing them into a double value, 
	 * and then increments the pointer by eight.
	 * @return The read short
	 * @throws BufferUnderflowException If there are fewer than eight bytes remaining in this reader
	 */
	public double readDouble() {
		return buffer.getDouble();
	}
	
	/**
	 * Skips the reader forward by x amount of bytes.<br>
	 * If the new position is larger than the reader's size, an IllegalArgumentException will be thrown
	 * @param bytes The amount of bytes to skip
	 * @throws IllegalArgumentException Is the new position is larger than the size
	 */
	public void skip(int bytes) {
		buffer.position(buffer.position() + bytes);
	}
	
	/**
	 * Skips the reader backward by x amount of bytes.<br>
	 * If the new position is less than than 0, an IllegalArgumentException will be thrown
	 * @param bytes The amount of bytes to skip
	 * @throws IllegalArgumentException Is the new position is larger than the size
	 */
	public void rewind(int bytes) {
		buffer.position(buffer.position() - bytes);
	}
	
    /**
     * Tells whether there are any elements between the current position and
     * the limit.
     *
     * @return  <tt>true</tt> if, and only if, there is at least one element
     *          remaining in this buffer
     */
	public boolean hasRemaining() {
		return buffer.hasRemaining();
	}
	
	/**
	 * Returns the number of elements between the current position and the limit.
	 * @return The number of elements remaining in this reader
	 */
	public int remaining() {
		return buffer.remaining();
	}
	
	/**
	 * Reads a string from the current position in the reader. <br>
	 * First, an integer is read, this should be the length of the string.
	 * Next the reader reads the length of the string, converts it to a string and returns.<br>
	 * Problems arise if the where buffer's current position was never where a string was written to. 
	 * In which case, an IllegalStateException will be thrown indicating that the string attempting to be read 
	 * is not a valid string. Make sure that there is a string written to the same position as the current offset.
	 * @return The read string
	 * @see TroyWriter#writeString(String)
	 */
	public String readString() {
		int bytes = readInt();
		if((long)bytes + buffer.position() >= buffer.capacity()) throw new IllegalStateException
		("The \"String\" being read is longer than the buffer!\nThe String should've started at " + (buffer.position() - 4) + " string length " + bytes);
		byte[] data = new byte[bytes];
		for(int i = 0; i < bytes; i++) {
			data[i] = readByte();
		}
		return new String(data);
	}
	
	/**
	 * Returns how far the reader is into the data
	 * @return The offset in bytes from the start
	 */
	public int getPointer() {
		return buffer.position();
	}
	
	/**
	 * Moves the pointer of the reader to the desired position. All read calls after this will read from this new pointer.
	 * @param newPointer The new pointer to use
	 */
	public void setPointer(int newPointer){
		buffer.position(newPointer);
	}

}
