package com.troyberry.util;

import java.io.*;

import com.troyberry.util.data.*;

/**
 * A class that has some static miscellaneous utilities.
 * @author Troy Neubauer
 *
 */
public class MiscUtil {
	
	/**
	 * Reads the desired file to a String assuming it exists
	 * @param file The file to read
	 * @return The String representing the file
	 * @throws IOException If the file doen't not exist or if a IO error occurs while reading the file
	 */
	public static String readToString(MyFile file) throws IOException {
		StringBuilder sb = new StringBuilder(512);
		BufferedReader reader = file.getReader();
		String line;
		while((line = reader.readLine()) != null) {
			sb.append(line);
		}
		return sb.toString();
	}
	
	/**
	 * Reads the desired file to a String assuming it exists
	 * @param file The file to read
	 * @return The String representing the file
	 * @throws IOException If the file doen't not exist or if a IO error occurs while reading the file
	 */
	public static String readToString(File file) throws IOException {
		StringBuilder sb = new StringBuilder(512);
		BufferedReader reader = new BufferedReader(new FileReader(file));
		String line;
		while((line = reader.readLine()) != null) {
			sb.append(line);
		}
		return sb.toString();
	}
	
	/**
	 * Reads the desired file to a byte array
	 * @param file The file to read
	 * @return The data in the file
	 * @throws IOException If the file doen't not exist or if a IO error occurs while reading the file
	 */
	public static byte[] readToByteArray(File file) throws IOException {
		if(file == null) throw new NullPointerException("File can't be null!");
		byte[] data = new byte[(int) file.length()];
		FileInputStream stream = new FileInputStream(file);
		stream.read(data);
		return data;
	}
	
	/**
	 * Generates a long from a string by adding the ASCII codes together. The long is more of less random but the same string 
	 * will always return the same result.</br>
	 * This is useful for using a string to seed a random number generator. In that case, the user will be able to enter 
	 * something like "Troy is cool" and the output of random numbers would always be the same as long as "Troy is cool" was 
	 * the seed. However, as soon as the user changes what they entered to lets say "Troy is awesome", the seed would be different.
	 * @param s The string to convert
	 * @return A long representing the string that can be used scenarios
	 */
	public static long getlong(String s) {
		long number = 0;
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			number += ((int) c) * ((long) Math.pow(10, i));
		}
		return number;
	}
	
	public static String getStackTrace(Throwable error) {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		error.printStackTrace(pw);
		return sw.toString();
	}

	public static String epochToString(long time) {
		return new java.text.SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(new java.util.Date (time));
	}
	
	private MiscUtil() {
		
	}
}
