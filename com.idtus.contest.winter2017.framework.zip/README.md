# IDT2016-2017
This is out submission for IDT 2017 (http://contest.idtus.com/contest/). This is out submission
# Rember to update this later to say somthing better
