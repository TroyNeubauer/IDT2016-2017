package contest.winter2017.reader.panel;

import java.awt.*;

import javax.swing.*;

public class GettingStartedPanel extends JPanel {

	public GettingStartedPanel() {
		super();
		add(new JLabel("Getting started"));
	}


}
